# Faturamento — `/billing`

> Where: sidebar › Esteira › Faturamento (receipt icon; no counter) · also reached from the "N no Faturamento" pointer inside an open file on the Revisão, the Dashboard's robot/billed tiles and bill rows, and the global search's Contas results · Status: built (Pro decision 023; validated live 16/08/2026) · Code: `src/routes/billing/+page.svelte`, `src/lib/billing.svelte.ts`, `src/lib/ipc.ts` (`Bill`, `PhaseOnScreen`, `RecoverAnswer`), `src-tauri/src/billing.rs`, `src-tauri/src/lib.rs` (`bill_from_record`, `list_billing`, `ingest_bill`, `process_bill`, `recover_run`, `resolve_bill`, `withdraw_bill`), `src-tauri/src/fantasma.rs`

## The question

"O que aconteceu com a conta depois que eu aprovei?" (i18n `question.billing`; not drawn on the screen). Put as work: where is each bill, and what do I do about the one that stopped.

## Where it sits in the work

- **Third station of the conveyor.** A bill arrives here the moment Aprovar, on the [Revisão](03-review.md), writes its file into the Fantasma's queue folder. Approval also tries to hand the bill to the robot's work list on the way ("entregar"); when that fails (Docker down), the bill arrives undelivered and this screen offers "Entregar ao Fantasma".
- **The bill is a token — present on exactly one screen.** Approved, it leaves the Revisão entirely (only a quiet "N no Faturamento" pointer stays there) and lives here. "Retirar da fila" walks it back: it reappears on the Revisão under "A conferir". A finished run sweeps its queue file; a failed run keeps it (there is still work).
- **The robot.** The Fantasma is a robot in a Docker container driving the ERP (the Everest) over a remote desktop. This screen holds the app's **only** gesture that can make it write to the ERP ("Processar conta"). The robot's cycle ends at "Pedido criado"; the invoice itself is the ERP's own act, by another path.
- **No outbox.** Everything comes back through the run itself: phase announcements while the robot works, one outcome at the end. A run the app did not survive is recovered from the robot's own job trace ("Recuperar o desfecho").
- Bills approved before the billing record existed are adopted on every list read, arriving undelivered.
- The [Dashboard](01-dashboard.md) reads this screen's store (funnel, "Só anda com você", stalled buckets, Hoje). No bell notice is posted about bills: a run's result is visible here and on the Dashboard only.
- The [shell](../04-shell.md) carries the toasts, the status bar's Fantasma block and the Configurações doors this screen points at in words.

## Anatomy

Two bands: a top bar across the width, and a body split into a scrolling list and a fixed detail panel.

### 1. Top bar (divider under it)
- **Title** "Faturamento".
- **Counter line** under it: "{a} a processar · {b} provável(is) · {c} falha(s) · {d} concluída(s)" — always over **all** bills, ignoring the filters (definitions in § Data shown).
- At the right: the **client menu** button — "Todos os clientes" or the chosen client id, with a caret; opens a small menu listing "Todos os clientes" then every client id present among the bills (sorted), a check mark on the active one; closes on a choice or a click outside.
- The **view switch**, three segments: "Em andamento" (default) · "Concluídas" · "Todas".

### 2. List pane (flexible width, scrolls)
- **2a. Robot banner** — drawn only once the Fantasma's state has been answered (polled). A dot, a title and a sub line:

| Situation | Dot | Title | Sub line |
|---|---|---|---|
| a gesture of this window is in flight | pulsing (static under reduced motion); green or amber as below | "Processando agora: {PACIENTE}" | follows the robot state, as below |
| robot "ready" or "foreign" | green | "Robô pronto" | "Sessão aberta no Everest — pronto para processar." |
| any other robot state (off, container up without session, starting, stopping) — also when unconfigured | amber | "Robô parado" | "Nada será processado até o Fantasma estar de pé — ligue em Configurações → Fantasma." |

- **2b. Failure banner** — conditional, red: the last refused read or gesture, verbatim. Drawn only when the view has rows.
- **2c. Column heads** (small uppercase): "Conta" · "Veredicto do Everest" · "Estágio no robô". **[functional]** verdict and stage are separate columns and never share a cell.
- **2d. Rows** — one card per bill, stacked with small gaps, newest record write first. A row is a button (click selects). Three cells:
  - **Conta** (flexible): patient name (truncates) + insurer chip; under it `{atendimento}` (mono) · `{client id}` · "{N} itens".
  - **Veredicto do Everest** (172 px): either the finished bill's document number as a neutral mono pill — "Pedido 420001" (or "Conferência 170001" when only a conferência exists) — or the verdict pill, or **nothing**; followed by "checado {age}" when an answer was recorded.
  - **Estágio no robô** (230 px): four thin segments (tooltip on each: "No Faturamento", "Conferência", "Encerrada", "Pedido criado") + a short stage text.
  - A 3 px colored bar on the row's leading edge: accent when "Processar" is available, amber when the bill needs investigation, red when it failed (red wins over accent). Selected row: accent-tinted border.
- **Empty view**: the shared `EmptyState` ([components](../05-components.md)) with a tray icon, "Nada em andamento" and "Aprovar uma conta na Revisão a coloca aqui — na fila do Fantasma, pronta para o robô."

### 3. Detail panel (fixed 352 px, divider on its left, scrolls) **[functional: the gestures live only here, beside the facts of the one selected bill]**
Always present. With no row to show: `EmptyState` with a left arrow and "Escolha uma conta na lista para ver o detalhe." Otherwise, top to bottom:
1. **Name** (patient) and a **meta line**: `{atendimento}` · `{client id}` · `{convênio}` · "{N} itens" · `{approval date dd/mm/aaaa}`.
2. **Verdict row**: the verdict pill (never the document number here) + "checado {age}" when checked.
3. **Notes**, each conditional:
   - Investigation (amber fill): "Duplicidade com dúvida — o Everest respondeu “provável”; confira no ERP antes de decidir."
   - Stopped mid-run (amber fill, hidden while this bill's own gesture is in flight): "Uma corrida ficou pelo meio — o desfecho não chegou; a barra está onde as fases pararam." + button "Recuperar o desfecho".
   - Abort (red fill): title with a warning icon = the worded abort reason; under it, in mono, the robot's own sentence verbatim.
   - Last refusal (red fill): "Última falha" + the refusal's text in mono, verbatim.
4. **Checklist** titled "O que já foi feito / o que resta": three steps — "Conferência", "Encerrada", "Pedido criado" — each with a filled check (done), a filled cross plus " — parou aqui" (the step a failed bill stopped at), or a dashed circle (still to do).
5. **Point-of-no-return note** (amber outline) when the bill is not finished and has reached "Encerrada": "A conferência já foi encerrada no Everest — retirar não desfaz; retomar o pedido é o caminho."
6. **Work-list footnote** when the robot's own list holds the bill as "revisar": "O Fantasma já processou esta conta e a linha dela saiu de pendente na lista de trabalho dele — está em revisar. Processar de novo exige devolvê-la à lista lá."
7. **Lots block** when the outcome carried per-lot answers: "O que o Everest respondeu, por lote" + one line per lot: `{lote}` (mono) — `{the Everest's phrase, verbatim}`.
8. **Actions stack** (§ Actions): the delivery button or the "Entregue ao Fantasma {age}" line (lock icon), then "Processar conta", "Assinar como resolvida", "Retirar da fila" as each applies. A confirmation opens **inline, in place of its button**, inside this stack.

## Data shown

**Row facts** are frozen at approval: patient, insurer (the resolved registry name when one was matched), client id, atendimento, item count, approval instant. Everything else comes from the robot.

| Field | Meaning | Presentation rule | Example |
|---|---|---|---|
| Patient | the bill's patient as approved | row title; detail title | MARTA LEMOS FERREIRA |
| Convênio | insurer | chip in the row; plain in the detail meta | VIDA PLENA SAÚDE |
| Atendimento | admission number | mono | 2026004517 |
| Client id | the adapter's id | raw id (row, detail, client menu) | vale_verde |
| Items | items in the bill | "{N} itens" (the same plural word for 1) | 6 itens |
| Approval date | when Aprovar wrote the file | detail meta only, dd/mm/aaaa | 08/09/2026 |
| Verdict | what the Everest answered about duplicates, set only when a run's outcome is recorded | pill; **none** when not checked — table below | "sem registro" |
| Checked | when that outcome was recorded | "checado agora" / "checado há N min" / "checado há N h" (under 48 h) / "checado dd/mm/aaaa" | checado há 12 min |
| Stage | how far the robot took it: 0 No Faturamento · 1 Conferência · 2 Encerrada · 3 Pedido criado | segments lit up to the stage reached; all lit segments green once finished | 2 of 4 lit |
| Stage text | — | while this bill's gesture runs and a phase arrived: the phase words; else "Concluída" when finished; else the reached stage's word | "lançando a conferência…" |
| Document number | the order created, else the conferência closed | row verdict cell of a **finished** bill: "Pedido {n}" / "Conferência {n}" (mono, neutral) | Pedido 420001 |
| Abort reason | the phase that stopped the run, as a key | worded (table below); an unknown key shows raw | "Sem saldo para faturar" |
| Robot sentence | the robot's own reason for the abort | mono, verbatim, wrapped | (illustrative) "saldo do lote 902211 abaixo da quantidade pedida" |
| Last refusal | the text of the last refused Processar (Docker's or the robot's words, or the app's refusal) | "Última falha" + mono verbatim; cleared when the next run starts | — |
| Delivered | when the bill was put on the robot's work list | "Entregue ao Fantasma {age}" with a lock icon | Entregue ao Fantasma há 41 min |
| Lots | the Everest's phrase per lot, from the outcome | one line per lot, phrase verbatim | 451288 — SEM REGISTRO |

**Verdict pills** (the look is the current build's grammar):

| Verdict | Text | Look | When |
|---|---|---|---|
| not checked | — (**no pill**) | — | the normal state: no outcome yet, or an outcome that neither went through nor was a Rule 1 ending (a failure) |
| no record | "sem registro" | outlined green — a "go", never a solid button-like fill | the run went through: there was no record, and now there is an order |
| billed | "faturada" | neutral, "locked" (a fact, not an alarm) | Rule 1 ending, and at least one lot answered FATURADA |
| waiting | "aguardando" | outlined accent | Rule 1 ending with no FATURADA lot — the order exists, the invoice not yet |
| likely | "provável" | amber | Rule 1 ending that left a question (partial, or a lot phrase that is not a settled answer) → needs investigation |

**Abort reasons** (worded keys): "duplicidade" → "Regra 1 — o Everest já tem registro desta conta" (never shown in practice: a Rule 1 ending is not a failure) · "saldo" → "Sem saldo para faturar" · "paciente" → "Paciente não encontrado no Everest" · "colinha" → "Colinha incompleta do lado do robô" · "pedido_express" → "O pedido express falhou" · "ensaio" → "Ensaio — nada foi gravado" (a dry run; drawn as a failure).

**Live phase words**: "validando" → "validando…" · "duplicidade" → "checando duplicidade no Everest…" · "conferencia" → "lançando a conferência…" · "encerrada" → "encerrando a conferência…" · "pedido_criado" → "criando o pedido…"; any other phase shows its raw key.

**How the stage is known.** With an outcome: conferência + order → Pedido criado; conferência only → Encerrada; otherwise No Faturamento. Without an outcome (a run in progress or one the app did not survive): the stamps written mid-run — order → Pedido criado; conferência or the point-of-no-return stamp → Encerrada; else No Faturamento. "Conferência" (stage 1) exists only live, from a phase; after a run that failed there, the bar returns to "No Faturamento" and the checklist marks "Conferência — parou aqui". A live phase can only move the bar forward.

**Counters in the top bar** (over all bills, both filters ignored):

| Counter | Counts |
|---|---|
| "a processar" | bills delivered, not finished, below "Encerrada" (live phase included), and not already closed on the robot's own list — exactly the rows where "Processar conta" is offered |
| "provável(is)" | bills needing investigation and not finished |
| "falha(s)" | bills whose run failed (a signed failed bill still counts) |
| "concluída(s)" | finished bills: the run went through, or Rule 1 ended it with no question, or the operator signed it |

**Views**: "Em andamento" = not finished · "Concluídas" = finished · "Todas". The client menu narrows to one client id. **Order**: newest record write first — a bill jumps to the top whenever it is delivered, processed or recovered.

## States

### Screen states

| State | Trigger | What is drawn |
|---|---|---|
| Not asked yet | first list read not answered | List area blank (no rows, no empty sentence); the detail panel shows "Escolha uma conta na lista para ver o detalhe."; the robot banner appears as soon as the Fantasma answers. |
| Refreshing | every 5 s while the screen is open (list + robot state) | silent |
| Empty view | no bill matches the view and client | `EmptyState` "Nada em andamento" + note — the same sentence under "Em andamento", "Concluídas", "Todas" or a client with nothing; detail panel "Escolha uma conta…". |
| List read refused | the record could not be listed | Red banner above the column heads, verbatim — when the view has rows. With no rows, the empty state is what shows. |
| Robot ready / foreign | Fantasma state | green banner "Robô pronto" |
| Robot not ready | off, up without session, starting, stopping, unconfigured | amber banner "Robô parado" + the Configurações sentence. Nothing on the list is disabled by it. |
| Robot never answered | status unknown | no banner at all |
| Robot busy with another task | its lock held by a catalog collection, a query or a start/stop | not shown on this screen; a Processar started then is refused with "o Fantasma está ocupado — aguarde o gesto atual terminar" |
| A gesture of this window in flight | Entregar, Processar, Recuperar, Assinar or Retirar running | every gesture button in the panel disabled; the banner reads "Processando agora: {PACIENTE}" with the pulsing dot, whatever the gesture; the running bill's button reads "…" (Entregar) or "Processando…" (Processar) |
| Run in progress | Processar running | stage text in accent showing the live phase; segments advance phase by phase; crossing "Encerrada" makes "Processar" and "Retirar" vanish mid-run and the point-of-no-return note appear. Phases are listened to only while this screen is open; away from it the bar catches up from the stamps on return. |
| Narrow window | — | No breakpoint: the panel keeps 352 px and the verdict/stage cells keep their widths; the Conta cell shrinks and truncates. |

### Bill states (independent facts — a bill can hold several at once)

| Bill state | Row | Detail panel | Gestures offered |
|---|---|---|---|
| Approved, not delivered | no pill · 1 segment · "No Faturamento" · no edge bar | "Entregar ao Fantasma" + "Coloca a conta na lista de trabalho do robô — nada é escrito no ERP neste gesto." | Entregar · Retirar |
| Delivered, waiting | no pill · 1 segment · "No Faturamento" · accent edge | "Entregue ao Fantasma há 41 min" | Processar · Retirar |
| Running (this window) | live phase text · advancing segments · banner | "Processando…" (disabled); the mid-run note is hidden | none until it ends |
| Finished — order created | "Pedido 420001" · 4 green segments · "Concluída" | verdict "sem registro"; checklist all done; lots | none |
| Finished — Rule 1 whole | "faturada" or "aguardando" pill · first segment green · "Concluída" · **never red** | lots phrases; no abort note | none |
| Needs investigation | "provável" pill · amber edge · "No Faturamento" | amber investigation note; lots | Retirar (and "Assinar como resolvida" only if a refusal is recorded) |
| Failed | no pill, "checado há …" · red edge · segments at the stored stage | red abort note (reason + robot sentence); the next step "— parou aqui"; the "revisar" footnote | Processar and Retirar while below "Encerrada" |
| Stopped mid-run (the app died during a run) | bar where the stamps left it | amber note + "Recuperar o desfecho"; the point-of-no-return note when at "Encerrada" or beyond | Recuperar; Processar and Retirar too while below "Encerrada" |
| Past the point of no return, not finished | 3–4 segments · "Encerrada"/"Pedido criado" | amber-outlined point-of-no-return note | no Processar, no Retirar |
| Last refusal recorded | — | red "Última falha" + verbatim text | "Assinar como resolvida" (when not finished) |
| Signed as resolved | the number pill if any, else the verdict pill · green segments · "Concluída" | — | none |

## Actions

All gestures act on the **selected** bill, in the detail panel. Only one gesture at a time: while one is in flight every gesture button is disabled, and a second request is refused on both sides (this window, and the robot's single-flight lock shared with collections, queries and start/stop).

| Gesture | Shown when | Disabled when | Effect | Confirmation | Reversible | Feedback |
|---|---|---|---|---|---|---|
| Select a row | always | never | selects the bill; **closes any open confirmation** | no | yes | selected border; the panel follows |
| Client menu | always | never | narrows the list to one client id | no | yes | button shows the id; check mark in the menu |
| View switch | always | never | "Em andamento" / "Concluídas" / "Todas" | no | yes | active segment tinted accent |
| "Entregar ao Fantasma" | the bill was never delivered | a gesture in flight | puts the queue file on the robot's work list; writes nothing to the ERP; stamps the delivery | none | via "Retirar da fila" | button reads "…" while running; ok toast "Conta entregue ao Fantasma."; refusal: danger toast with the service's sentence (e.g. "esta conta já foi entregue ao Fantasma") |
| "Processar conta" | delivered, not finished, below "Encerrada", not closed on the robot's list | a gesture in flight | the robot works this one bill in the Everest, for minutes: duplicate check, conferência, closing, order; the outcome is recorded | inline: **"Processar esta conta?"** "É o único gesto que escreve no ERP — uma conta por vez, e a conferência não se cancela depois de encerrada." [Processar] [Cancelar] | **no** — past "Encerrada" nothing is undone | "Processando…", banner, live bar; when an outcome arrives (whatever it says) ok toast "Corrida concluída — veja o veredito na linha."; a refusal from the run itself is recorded as "Última falha" (the busy-lock and not-delivered refusals are not) and is meant to toast |
| "Recuperar o desfecho" | the bill stopped mid-run and is not running here | a gesture in flight | reads the robot's job trace; if an outcome is there, records it exactly as a live run would | none | nothing is written unless an outcome is found | "recovered" → ok "Desfecho recuperado do rastro do Fantasma." · "no trace" → warn "O Fantasma não tem rastro desse job — o expurgo provavelmente já o levou. Nada foi gravado." · "still running" → warn "A corrida consta como EM ANDAMENTO do lado do Fantasma: ou ainda anda, ou morreu sem registrar o fim. Nada foi gravado." · "no outcome" → warn "O job terminou, mas não há desfecho no rastro dele. Nada foi gravado — veja o rastro completo em Logs." |
| "Assinar como resolvida" | not finished and a refusal is recorded | a gesture in flight | records the operator's word (checks nothing); the bill becomes finished, leaves "Em andamento", its queue file is swept; the first signature stands | inline: "Assinar diz que VOCÊ conferiu no Everest e a conta está encerrada — o app grava a sua palavra e nada mais. A conta sai do Em andamento." [Assinar] [Cancelar] | no gesture undoes it | ok toast "Assinada — encerrada pela sua palavra." |
| "Retirar da fila" | not finished and below "Encerrada" | a gesture in flight | the robot's own withdrawal first (when delivered — it refuses anything past pending), then the queue file, then the record; the bill reappears on the Revisão under "A conferir" | inline: "Retirar esta conta da fila do Fantasma?" [Retirar] (danger tint on hover) [Cancelar] | yes — approve it again on the Revisão | ok "Conta retirada — voltou para a Revisão." · warn "Nada havia para retirar — o robô pode já tê-la levado." · refusal past the point of no return: "a conferência já foi encerrada no Everest — retirar não desfaz; o caminho é retomar o pedido, nunca refazer a conta" |

Other refusal sentences a gesture can bring back (verbatim, Rust side): "esta conta não está no registro do faturamento" · "esta conta ainda não foi entregue ao Fantasma" · "a Pasta do projeto não está configurada — Configurações → Fantasma" · "a conta saiu do registro durante a corrida" · "esta conta não tem corrida registrada para consultar" · "o processar terminou sem desfecho — saída:" + the run's output · "não entendi o desfecho do processar:" + the raw line · Docker's or the robot's own words, verbatim. Toasts are the shell's ([shell](../04-shell.md)).

No keyboard shortcuts. Rows, menu entries and gestures are native buttons (Tab / Enter); the client menu does not close on Esc in the current build.

## Business rules

1. **Two dimensions, never merged.** The verdict (what the Everest answered) and the stage (how far the robot took it) are different facts in different cells (023 § 4; telas.md).
2. **"Não checado" draws no pill.** It is the normal state of every bill in the queue; green exists only after someone asked. This app once queued eleven bills behind a hard-coded green "sem registro", all already invoiced (inherited rule; AGENTS.md).
3. **A finished bill wears its document number in the list**, not a pill — the fact that settles it (023 § 4).
4. **Rule 1 refusing is an ending, never a failure.** "Already invoiced" is the answer the check exists to get: nothing written, nothing to redo — never red (023 § 4).
5. **No button processes the queue. One bill, one click, with confirmation.** No app-side batch or serial queue: the agreement with the robot's side is to grow the batch slowly, and a queue surviving the app would write to the ERP unsupervised at the next launch (023 § 2; inherited 016).
6. **One gesture at a time; the second is refused**, here and by the robot's single-flight lock, which every Fantasma gesture shares (012).
7. **Sign of life before the call.** A run answers only at its end, minutes later; the busy mark goes on before the command leaves (AGENTS.md "The machine").
8. **"Encerrada" is the point of no return.** The Everest does not cancel a closed conferência. Past it, "Processar" and "Retirar" disappear (mid-run too), the note names the path, and the withdrawal is also refused where the file is handled (023 § 2).
9. **Resume, never redo.** A bill stopped between "Encerrada" and "Pedido criado" is not redone — redoing is the definition of a duplicated invoice; the screen says "retomar o pedido é o caminho" (inherited 016). The resume gesture itself is deferred (023 § 5).
10. **The reason is a key worded by the app; the robot's sentence rides beside it, verbatim, never interpreted** — a sentence improved on the other side must not break this screen in silence (023 § 4; inherited 016).
11. **A lot phrase is read by how it starts, never by what it contains.** "PROVÁVEL AGUARDANDO — …" contains "AGUARDANDO" and is still a question, not "aguardando"; an unrecognized phrase is a question, never "faturada" (023 § 7).
12. **Phases are progress, not state.** A lost phase costs a lagging bar, never a mistake; the bar only moves forward; the outcome at the end corrects it (023 § 3).
13. **"Stopped mid-run" means it died without an answer.** A run that ended in a refusal answered — it shows "Última falha", not the mid-run note (023 § 8).
14. **A confirmation never survives a selection change.** An open "Processar?" following the click onto another row would be one yes away from the wrong bill (023 § 8).
15. **Signing records a word and checks nothing** — for bills the robot's own list already closed (work from before this app) or settled by hand in the Everest (023 § 8).
16. **"Entregar" writes nothing to the ERP and needs no confirmation**; approval tries it on the way and may fail without failing the approval (023 § 2).
17. **"Retirar" order: the robot's verb first, our file after, the record last** — their refusal of anything past pending is the safety this side must not re-implement (023 § 2).
18. **The robot's cycle ends at "Pedido criado".** No "Faturada" step: a fifth step that never completes left every done bill looking unfinished (006 § 2).
19. **The first stage is called "No Faturamento".** "Fila" once meant two things (the dock's "aguarda extração" and this queue), and the operator went looking here for bills never approved; a second meaning for a glossary word is a defect (002; project memory 17/08/2026).
20. **The banner shows the robot's real session**, polled, never a remembered flag.
21. **The billing record stays on this machine.** It carries a patient's name, lives in the app's config directory, and never enters git or any export (023 § 1).

## Must survive the redesign

- Verdict and stage as two separate, simultaneously visible facts per row.
- No pill (no color, no placeholder word) for "not checked"; green only for "sem registro" earned by a run.
- The finished row's document number; Rule 1 endings never drawn as errors.
- The four stages with these words, ending at "Pedido criado"; the live movement during a run; the bar never moving backward.
- Gestures only on the one selected bill, one at a time, disabled while any is in flight; no bulk selection and no "process all".
- The inline confirmation texts for Processar, Retirar and Assinar, attached to the selected bill and closed by any selection change.
- "Processar" and "Retirar" absent (not just disabled) from "Encerrada" on, with the point-of-no-return sentence present.
- The mid-run note with "Recuperar o desfecho"; the four recovery outcomes worded apart.
- The abort reason worded + the robot's sentence verbatim in a code-like face; "Última falha" verbatim; lot phrases verbatim.
- The "Entregar" footnote (nothing written to the ERP) and the "Entregue ao Fantasma há …" fact.
- The robot banner reflecting the real session.
- Amber only for investigation (a human must decide) and the robot not ready; red for failures; accent for "workable now".

## Free to redesign

- The two-pane layout, the panel width, list-as-cards vs. table (this list does not use the shared Grid), row density.
- The segment bar's form (steps, dots, a timeline), as long as it reads as four ordered stages and stays apart from the verdict.
- Pill shapes and the edge-bar signal for workable/amber/red rows.
- Where the counters, the client filter and the view switch sit; the banner's form.
- The checklist's look; how the lots block is laid out; the order of the notes.
- Whether confirmations stay inline or become an anchored popover — provided they stay tied to the selected bill.

## Sample content for mockups

Cast from [06-sample-data](../06-sample-data.md); robot sentences and some numbers are illustrative.

| Patient | Convênio | Atend. · client · items | State | Row verdict cell | Stage | Detail highlights |
|---|---|---|---|---|---|---|
| MARTA LEMOS FERREIRA | VIDA PLENA SAÚDE | 2026004517 · vale_verde · 6 itens | finished, order | "Pedido 420001" · "checado há 12 min" | 4 green · "Concluída" | verdict "sem registro"; lots: 451288 — SEM REGISTRO · A7K2219 — SEM REGISTRO · C24B0917 — SEM REGISTRO |
| JOÃO CARLOS PRADO | AMPARO SAÚDE | 2026004602 · santa_aurora · 3 itens | running | — | 2 lit · "lançando a conferência…" (accent) | banner "Processando agora: JOÃO CARLOS PRADO"; "Processando…" |
| LUÍSA ANDRADE REIS | SUS | 2026004633 · horizonte · 4 itens | delivered | — | 1 lit · "No Faturamento" · accent edge | "Entregue ao Fantasma há 41 min"; Processar conta; Retirar da fila |
| PEDRO HENRIQUE SALLES | PARTICULAR | 2026004688 · vale_verde · 2 itens | not delivered | — | 1 lit · "No Faturamento" | "Entregar ao Fantasma" + footnote |
| BEATRIZ MONTEIRO | VIDA PLENA SAÚDE | 2026004701 · santa_aurora · 5 itens | Rule 1 whole | "faturada" · "checado há 2 h" | 1 green · "Concluída" | lots: 902211 — FATURADA — Nota 100245 |
| CARLOS EDUARDO LIMA | AMPARO SAÚDE | 2026004715 · horizonte · 3 itens | investigation | "provável" · "checado há 20 min" | 1 lit · amber edge | amber note; lots: 0000451288 — PROVÁVEL AGUARDANDO — Pedido 420001 (CONFERIR: nome ≈ …) |
| MARTA LEMOS FERREIRA | AMPARO SAÚDE | 2026004729 · vale_verde · 4 itens | failed, "saldo" | "checado há 1 h" | 1 lit · red edge | "Sem saldo para faturar" / "saldo do lote 902211 abaixo da quantidade pedida"; "Conferência — parou aqui"; "revisar" footnote |
| JOÃO CARLOS PRADO | VIDA PLENA SAÚDE | 2026004733 · santa_aurora · 2 itens | stopped mid-run at Encerrada | — | 3 lit · "Encerrada" | mid-run note + "Recuperar o desfecho"; point-of-no-return note; conferência 170001 on record |

Top bar for that set: "3 a processar · 1 provável(is) · 1 falha(s) · 2 concluída(s)" (the running, the delivered and the failed bill all count as "a processar"); menu "Todos os clientes" / horizonte / santa_aurora / vale_verde. Lot keys: unverified whether the robot reports the lot as read (451288) or as the ERP stores it (0000451288); both appear above on purpose.

## Design opportunities

1. **Name the gesture in flight.** The banner says "Processando agora: …" for every gesture, including a delivery, a withdrawal, a recovery or a signature. "Entregando…", "Retirando…", "Recuperando o desfecho…" would say what is actually happening.
2. **Show why "Processar" cannot work before the confirmation.** The button stays enabled when the robot is off, without a session, or busy with a catalog collection or a query; the refusal arrives only after "Processar". Carrying the robot state (and its busy lock) onto the button, with the reason, would stop a confirmed click from going nowhere.
3. **An empty sentence per view.** "Nada em andamento" also answers "Concluídas" and "Todas" (and a client with nothing); each view deserves its own absence.
4. **The panel with nothing to show.** With an empty list the panel still asks to "Escolha uma conta na lista…".
5. **Deep-link a bill.** The Dashboard, the Revisão pointer and the search all land on the list with its top row selected, not on the bill they named.
6. **Client names, not ids.** The menu and the rows show raw adapter ids ("vale_verde"); the adapters carry display names.
7. **Counters as filters.** The four counters ignore the filters and cannot be clicked; making them the filters (a processar, provável, falha, concluída) — or saying they count every client — would remove a mismatch between the line and the list under it.
8. **Show the numbers where they matter.** An unfinished bill that closed conferência 170001 never shows the number (only finished rows do); the point-of-no-return note is where the operator needs it to resume the order in the Everest.
9. **Doors to the trail.** The "no outcome" recovery says "veja o rastro completo em Logs" without a door; failed runs could link to Logs · Fantasma · Sessão.
10. **A place for "Retomar o pedido".** The resume gesture is deferred (023 § 5); the design can reserve its spot beside the point-of-no-return note so the day it arrives nothing moves.
11. **A decision gesture for "provável".** The investigation note asks the operator to check the ERP "antes de decidir", but the only gesture offered is "Retirar"; "Assinar como resolvida" appears only after a recorded refusal.
12. **Singular item count.** "1 itens".
13. **One clear guidance for stopped runs.** The Dashboard says "recupere o desfecho antes de qualquer novo gesto", while this panel offers "Processar" and "Retirar" beside "Recuperar" when the stop happened below "Encerrada".

## Open questions

- Refusal feedback: the page wires a danger toast for every refused gesture, but by code reading the list refresh that follows each gesture clears the refusal before the page reads it (engineering has the details). Draw the refusal toast; do not rely on the red banner as its only carrier.
- Is a phase announced when its step starts or when it ends? The words say "in progress" ("encerrando a conferência…") while the stage index treats the same phase as reached.
- unverified: whether the robot ever reports an abort at "pedido" (the stage rule knows it; the worded list has only "pedido_express").
- unverified: the lot key form in the outcome (as read vs. zero-padded by the ERP).
- Is showing "Processar conta" together with the "revisar" footnote ("Processar de novo exige devolvê-la à lista lá") intended?
- Should the Fantasma "foreign" state really read "Robô pronto · Sessão aberta no Everest" here, while the Dashboard's Serviços row draws it grey as "de fora do app"?
